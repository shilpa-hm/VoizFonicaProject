import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-postpaid-plan',
  templateUrl: './postpaid-plan.component.html',
  styleUrls: ['./postpaid-plan.component.css']
})
export class PostpaidPlanComponent implements OnInit {

  displayedColumns: string[] = ['plan', 'validity', 'data',  "getdetails"];
   dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  

  ngOnInit(): void {
  }
  getRecord(name: any)
  {
    alert(name);
  }
}
export interface PeriodicElement {
  plan: string;
  validity: string;
  data: string;
  // symbol: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  { plan: '299', validity: '30days', data: '20gb'},
  { plan: '399', validity: '45days', data: '25gb'},
  { plan: '499', validity: '60days', data: '30gb'},
  { plan: '599', validity: '65days', data: '35gb'},


];


  


