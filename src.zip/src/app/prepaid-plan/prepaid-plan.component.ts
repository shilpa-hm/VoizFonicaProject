import { Component, OnInit, ViewChild } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { BuiltinType } from '@angular/compiler';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
//import { defaultMaxListeners } from 'events';
//import { AppRoutingModule } from '../app-routing.module';
@Component({
  selector: 'app-prepaid-plan',
  templateUrl: './prepaid-plan.component.html',
  styleUrls: ['./prepaid-plan.component.css']
  
})
export class PrepaidPlanComponent implements OnInit {
  displayedColumns: string[] = ['plan', 'validity', 'data',  "getdetails"];
   dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  
  ngOnInit() {
    //this.dataSource.paginator = this.paginator;
  }
  getRecord(name: any)
  {
    alert(name);
  }
}
export interface PeriodicElement {
  plan: string;
  validity: string;
  data: string;
  // symbol: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  { plan: '299', validity: '30days', data: '1gb/day'},
  { plan: '399', validity: '45days', data: '1.5gb/day'},
  { plan: '499', validity: '60days', data: '1.5gb/day'},
  { plan: '599', validity: '65days', data: '2gb/day'},


];


  
