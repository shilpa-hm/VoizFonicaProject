import { Component, OnInit } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
@Component({
  selector: 'app-prepaid-plan',
  templateUrl: './prepaid-plan.component.html',
  styleUrls: ['./prepaid-plan.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class PrepaidPlanComponent implements OnInit {


  ngOnInit(): void {
  }
  dataSource = ELEMENT_DATA;
  columnsToDisplay = ['plan', 'validity', 'data'];
  expandedElement!: PeriodicElement | null;
}

export interface PeriodicElement {
  plan: string;
  validity: string;
  data: string;
  // subscription: string;
  description: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    plan: '249',
    validity: '28days',
    data: '3gb per day',
    // symbol: 'H',
    description: `hello`
  }, {
    plan: '699',
    validity: '40 days',
    data: '5gb per day',
    // symbol: 'He',
    description: `hello`
  }, {
    plan: '999',
    validity: '30 days',
    data: '2gb per day',
    // symbol: 'Li',
    description: `hello`
  },
];

