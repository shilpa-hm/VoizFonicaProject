import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup,FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
 user =new User();
 str="";
  public fg: FormGroup;
  
  constructor(private fb: FormBuilder,private service:RegistrationService,private router:Router) {
    this.fg = fb.group({
      fname:['', [Validators.required]],
      lname:['', [Validators.required]],
      email:['', [Validators.required]],
      password:['', [Validators.required]],
      dob:['', [Validators.required]],
      phone: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]]
    })
    
  }
    
  get p(){
    return this.fg.controls;
  }
   
  onFormSubmit(){
   if(this.fg.invalid){
     console.log("form not submitted")
     return;
   }else{
      this.onRegister();
   }
  } 
 onRegister(){
   this.service.onLogin(this.user).subscribe(
     data =>{this.router.navigate(["/login"])
     console.log("sucessful")

     },error =>{
       this.str="Emailid already exist"
       console.log("exception")
     }
   )
 }
  ngOnInit(): void {
  }

}
