import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup,FormControl } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  public fg: FormGroup;
  
  constructor(private fb: FormBuilder) {
    this.fg = fb.group({
      phone: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]]
    })
    
  }
    
  get p(){
    return this.fg.controls;
  }
   
  onFormSubmit(){
    alert(this.fg.value);
  } 

  ngOnInit(): void {
  }

}
