import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catalogue',
  templateUrl: './catalogue.component.html',
  styleUrls: ['./catalogue.component.css']
})
export class CatalogueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  members: {title: string, content: string,plan:string,new:string}[] = [

    {title: 'PREPAID', content: 'hello', plan:'View Plan',new:'New Prepaid Sim' },
    {title: 'POSTPAID', content: 'hello', plan:'View Plan',new:'New Postpaid Sim' },
    {title: 'DONGLE', content: 'hello',plan:'View Plan',new:'New Dongle' },
  ];
}
