import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { AboutComponent } from './about/about.component';
import { CatalogueComponent } from './catalogue/catalogue.component';
import { PrepaidPlanComponent } from './prepaid-plan/prepaid-plan.component';
import { RechargeComponent } from './recharge/recharge.component';
import { PaybillComponent } from './paybill/paybill.component';
import { PostpaidPlanComponent } from './postpaid-plan/postpaid-plan.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { BillingComponent } from './billing/billing.component';



const routes: Routes = [
  {path: '', component:WelcomeComponent},
  {path:'login',component:LoginComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'user-home',component:UserHomeComponent},
  {path:'about',component:AboutComponent},
  {path:'catalogue',component:CatalogueComponent},
  {path:'prepaidPlan',component:PrepaidPlanComponent},
  {path:'recharge',component:RechargeComponent},
  {path:'paybill',component:PaybillComponent},
  {path:'postpaidPlan',component:PostpaidPlanComponent},
  {path:'admin-home',component:AdminHomeComponent},
  {path:'billing',component:BillingComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
