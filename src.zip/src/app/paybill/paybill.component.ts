import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paybill',
  templateUrl: './paybill.component.html',
  styleUrls: ['./paybill.component.css']
})
export class PaybillComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
