import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-postpaid-plan',
  templateUrl: './postpaid-plan.component.html',
  styleUrls: ['./postpaid-plan.component.css']
})
export class PostpaidPlanComponent implements OnInit {

  displayedColumns: string[] = ['plan', 'validity', 'data',  "getdetails"];
   dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  constructor() { }

  ngOnInit(): void {
  }
  getRecord(name: any)
  {
    alert(name);
  }
}
export interface PeriodicElement {
  plan: string;
  validity: string;
  data: string;
  // symbol: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  { plan: 'one', validity: '30days', data: '20gb'},


];


  


